package com.sena.test.Controller.InventoryController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.InventoryDTO.CategoryDtoRequest;
import com.sena.test.DTO.InventoryDTO.CategoryDtoResponse;
import com.sena.test.IService.IInventoryService.IServiceCategory;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    private final IServiceCategory service;

    public CategoryController(IServiceCategory service) {
        this.service = service;
    }

    @PostMapping
    public CategoryDtoResponse create (@RequestBody CategoryDtoRequest dto) {
        return service.create(dto);

    }
    @GetMapping
    public List<CategoryDtoResponse> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public CategoryDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PutMapping("/{id}")
    public CategoryDtoResponse update(@PathVariable Long id, @RequestBody CategoryDtoRequest dto) {
        return service.update(id, dto);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
    



}
