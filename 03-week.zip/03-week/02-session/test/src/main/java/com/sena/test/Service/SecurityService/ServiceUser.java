package com.sena.test.Service.SecurityService;
import com.sena.test.Entity.Security.Person;
import com.sena.test.Entity.Security.User;

import java.util.List;
import java.util.stream.Collectors;

import com.sena.test.DTO.SecurityDTO.UserDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserDtoResponse;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryPerson;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryUser;
import com.sena.test.IService.ISecurityService.IServiceUser;
import com.sena.test.Utils.UserMapper;

public class ServiceUser implements IServiceUser{

    private final IRepositoryUser repository;
    private final IRepositoryPerson personRepository;

    public ServiceUser(IRepositoryUser repository,
                    IRepositoryPerson personRepository) {
        this.repository = repository;
        this.personRepository = personRepository;
    }

    @Override
    public UserDtoResponse create(UserDtoRequest dto) {

        Person person = personRepository.findById(dto.getPersonId())
            .orElseThrow(() -> new RuntimeException("Esta persona no fue encontrada"));

        repository.findByPersonId(person.getId())
            .ifPresent(u -> {
                throw new RuntimeException("Esta persona ya tiene un usuario");
            });
        User user = new User();
        user.setPassword(dto.getPassword());
        user.setUsername(dto.getUsername());
        user.setPerson(person);

        return UserMapper.toResponseDto(repository.save(user));

    }
    
    @Override
    public UserDtoResponse update(Long id, UserDtoRequest dto) {
    
    User user = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Person person = personRepository.findById(dto.getPersonId())
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));

        repository.findByPersonId(person.getId())
                .ifPresent(existingUser -> {
                    if (!existingUser.getId().equals(id)) {
                        throw new RuntimeException("Esta persona ya está asignada a otro usuario");
                    }
                });

        user.setPassword(dto.getPassword());
        user.setUsername(dto.getUsername()); // 🔹 SETEAR USERNAME
        user.setPerson(person);

        return UserMapper.toResponseDto(repository.save(user));
    }

    @Override
    public UserDtoResponse findById(Long id) {

        User user = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        return UserMapper.toResponseDto(user);
    }

    @Override
    public List<UserDtoResponse> findAll() {

        return repository.findAll()
                .stream()
                .map(UserMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {

        if (!repository.existsById(id)) {
            throw new RuntimeException("Usuario no encontrado");
        }

        repository.deleteById(id);

}
}
