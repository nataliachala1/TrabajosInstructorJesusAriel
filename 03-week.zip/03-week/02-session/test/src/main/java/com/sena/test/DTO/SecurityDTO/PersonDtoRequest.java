package com.sena.test.DTO.SecurityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonDtoRequest {
    private String name;
    private String lastName;
    private String email;
    private String identity;



}
