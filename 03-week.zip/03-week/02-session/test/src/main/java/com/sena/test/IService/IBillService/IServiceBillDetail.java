package com.sena.test.IService.IBillService;

import java.util.List;

import com.sena.test.DTO.BillDTO.BillDetailDtoRequest;
import com.sena.test.DTO.BillDTO.BillDetailDtoResponse;

public interface IServiceBillDetail {

    BillDetailDtoResponse createDetail(Long billId, BillDetailDtoRequest request);

    List<BillDetailDtoResponse> getDetailsByBillId(Long billId);

    void deleteDetail(Long id);

}
