package com.sena.test.Service.SecurityService;

import java.util.List;

import com.sena.test.DTO.SecurityDTO.PersonDtoRequest;
import com.sena.test.DTO.SecurityDTO.PersonDtoResponse;
import com.sena.test.Entity.Security.Person;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryPerson;
import com.sena.test.IService.ISecurityService.IServicePerson;
import com.sena.test.Utils.PersonMapper;

public class ServicePerson implements IServicePerson {

    private final IRepositoryPerson repository;

    public ServicePerson(IRepositoryPerson repository) {
        this.repository = repository;
    }

    @Override
    public PersonDtoResponse create(PersonDtoRequest dto) {
        validateUniqueFields(dto.getEmail(), dto.getIdentity(), null);

        Person person = PersonMapper.toEntity(dto);
        Person saved = repository.save(person);
        
        return PersonMapper.toResponseDto(saved);
    }

    @Override
    public PersonDtoResponse update(Long id, PersonDtoRequest dto) {

        Person person = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Persona no encontrada"));
        validateUniqueFields(dto.getEmail(), dto.getIdentity(), id);

        PersonMapper.updateEntity(person, dto);

        Person updated = repository.save(person);
        return PersonMapper.toResponseDto(updated);
    }

    @Override
    public PersonDtoResponse findById(Long id) {

        Person person = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Persona no encontrada"));

            return PersonMapper.toResponseDto(person);
    }

    @Override
    public List<PersonDtoResponse> findAll() {
        return repository.findAll()
            .stream()
            .map(PersonMapper::toResponseDto)
            .toList();
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Persona no encontrada");
        }

        repository.deleteById(id);

    }

    private void validateUniqueFields(String email, String identity, Long id) {
        repository.findByEmail(email)
            .filter(p -> id == null || !p.getId().equals(id))
            .ifPresent(p -> {
                throw new RuntimeException("El email ya esta en uso");
            });
        
        repository.findByIdentity(identity)
            .filter(p -> id == null || !p.getId().equals(id))
            .ifPresent(p -> {
                throw new RuntimeException("Esta identidad esta en uso");
            });
    }


}
