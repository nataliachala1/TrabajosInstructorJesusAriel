package com.sena.test.IRepository.ISecurityRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.test.Entity.Security.UserRol;

public interface IRepositoryUserRol extends JpaRepository<UserRol, Long>{

    List<UserRol> findByUserId(Long userId);

    List<UserRol> findByRolId(long rolId);

}
