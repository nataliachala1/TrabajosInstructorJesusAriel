package com.sena.test.Service.InventoryService;

import java.util.List;
import com.sena.test.Entity.Inventory.Category;
import java.util.stream.Collectors;

import com.sena.test.DTO.InventoryDTO.CategoryDtoRequest;
import com.sena.test.DTO.InventoryDTO.CategoryDtoResponse;
import com.sena.test.IRepository.IInventoryRepository.IRepositoryCategory;
import com.sena.test.IService.IInventoryService.IServiceCategory;
import com.sena.test.Utils.CategoryMapper;

public class ServiceCategory implements IServiceCategory {

    private final IRepositoryCategory categoryRepository;

    public ServiceCategory(IRepositoryCategory categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public CategoryDtoResponse create(CategoryDtoRequest dto) {
        if (categoryRepository.existsByName(dto.getName())) {
            throw new RuntimeException("Category already exists with name: " + dto.getName());
        }

    Category category = CategoryMapper.toEntity(dto);

    return CategoryMapper.toResponse(categoryRepository.save(category));
    
    }

    @Override
    public CategoryDtoResponse update(Long id, CategoryDtoRequest dto) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found with id: " + id));
                category.setName(dto.getName());
            return CategoryMapper.toResponse(categoryRepository.save(category));
    }

    @Override
    public CategoryDtoResponse findById(Long id) {
    Category category = categoryRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Category not found with id: " + id));
    return CategoryMapper.toResponse(category);
}

    @Override
    public List<CategoryDtoResponse> findAll() {
        return categoryRepository.findAll()
                .stream()
                .map(CategoryMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        if (!categoryRepository.existsById(id)) {
            throw new RuntimeException("Category not found with id: " + id);
        }
        categoryRepository.deleteById(id);
    }
}