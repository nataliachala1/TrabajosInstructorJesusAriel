package com.sena.test.Utils;

import com.sena.test.DTO.InventoryDTO.ProductDtoRequest;
import com.sena.test.DTO.InventoryDTO.ProductDtoResponse;
import com.sena.test.Entity.Inventory.Category;
import com.sena.test.Entity.Inventory.Product;

public class ProductMapper {

    private ProductMapper() {}

    public static Product toEntity(ProductDtoRequest dto, Category category) {
        Product product = new Product();
        product.setName(dto.getName());
        product.setPrice(dto.getPrice());
        product.setCategory(category);
        return product;
    }
    public static ProductDtoResponse toResponse(Product product) {
        ProductDtoResponse dto = new ProductDtoResponse();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setPrice(product.getPrice());

        if (product.getCategory() != null) {
            dto.setCategoryName(product.getCategory().getName());
        }

        return dto;
    }
}