package com.sena.test.IService.ISecurityService;

import java.util.List;

import com.sena.test.DTO.SecurityDTO.RolDtoRequest;
import com.sena.test.DTO.SecurityDTO.RolDtoResponse;

public interface IServiceRol {

    RolDtoResponse create(RolDtoRequest dto);
    RolDtoResponse update(Long id, RolDtoRequest dto);
    RolDtoResponse findById (Long id);
    List<RolDtoResponse> findAll();
    void delete (Long id);

}
