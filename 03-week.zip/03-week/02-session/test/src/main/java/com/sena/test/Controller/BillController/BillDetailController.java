package com.sena.test.Controller.BillController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sena.test.DTO.BillDTO.BillDetailDtoRequest;
import com.sena.test.DTO.BillDTO.BillDetailDtoResponse;
import com.sena.test.IService.IBillService.IServiceBillDetail;

public class BillDetailController {

    private final IServiceBillDetail service;

    public BillDetailController(IServiceBillDetail service) {
        this.service = service;
    }

    @PostMapping("/bill/{billId}")
    public BillDetailDtoResponse create(@PathVariable long billId, @RequestBody BillDetailDtoRequest dto) {
        return service.createDetail(billId, dto);
    }

    @GetMapping("/bill/{billId}")
    public List<BillDetailDtoResponse> getDetails(@PathVariable Long billId) {
        return service.getDetailsByBillId(billId);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteDetail(id);
    }

}
