package com.sena.test.DTO.SecurityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRolDtoRequest {

    private long userId;
    private Long rolId;

}
