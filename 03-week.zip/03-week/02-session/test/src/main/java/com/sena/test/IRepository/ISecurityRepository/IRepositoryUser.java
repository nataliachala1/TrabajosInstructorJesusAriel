package com.sena.test.IRepository.ISecurityRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.test.Entity.Security.User;

public interface IRepositoryUser extends JpaRepository<User, Long> {

    Optional<User> findByPersonId(Long personId);

}
