package com.sena.test.Service.BillService;

import java.util.List;
import java.util.stream.Collectors;

import com.sena.test.DTO.BillDTO.BillDetailDtoRequest;
import com.sena.test.DTO.BillDTO.BillDetailDtoResponse;
import com.sena.test.Entity.Bill.Bill;
import com.sena.test.Entity.Bill.BillDetail;
import com.sena.test.Entity.Inventory.Product;
import com.sena.test.IRepository.IBillRepository.IRepositoryBill;
import com.sena.test.IRepository.IBillRepository.IRepositoryBillDetail;
import com.sena.test.IRepository.IInventoryRepository.IRepositoryProduct;
import com.sena.test.IService.IBillService.IServiceBillDetail;
import com.sena.test.Utils.BillDetailMapper;

public class ServiceBillDetail implements IServiceBillDetail {

    private final IRepositoryBill repositoryBill;
    private final IRepositoryBillDetail repositoryBillDetail;
    private final IRepositoryProduct repositoryProduct;

    public ServiceBillDetail(IRepositoryBill repositoryBill,
                            IRepositoryBillDetail repositoryBillDetail,
                            IRepositoryProduct repositoryProduct) {
            this.repositoryBill = repositoryBill;
            this.repositoryBillDetail = repositoryBillDetail;
            this.repositoryProduct = repositoryProduct;
    }

    @Override
    public BillDetailDtoResponse createDetail(Long billId, BillDetailDtoRequest dto) {

        Bill bill = repositoryBill.findById(billId)
            .orElseThrow(() -> new RuntimeException("Bill not found"));

        Product product = repositoryProduct.findById(dto.getProductId())
            .orElseThrow(() -> new RuntimeException("Product not found"));
        
        BillDetail detail = BillDetailMapper.toEntity(dto, bill, product);
        detail = repositoryBillDetail.save(detail);

        double total = repositoryBillDetail.findByBillId(billId).stream()
            .mapToDouble(d -> d.getPrice() * d.getQuantity())
            .sum();
        bill.setTotal(total);
        repositoryBill.save(bill);

        return BillDetailMapper.toResponseDto(detail);
    }

    @Override
    public List<BillDetailDtoResponse> getDetailsByBillId(Long billId) {
        return repositoryBillDetail.findByBillId(billId).stream()
            .map(BillDetailMapper::toResponseDto)
            .collect(Collectors.toList());
    }  

    @Override
    public void deleteDetail(Long id) {
        repositoryBillDetail.deleteById(id);
    }

}
