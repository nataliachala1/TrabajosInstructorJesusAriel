package com.sena.test.DTO.InventoryDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDtoResponse {

    private Long id;
    private String name;
    private Double price;
    private String categoryName;

}
