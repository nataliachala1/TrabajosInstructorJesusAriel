package com.sena.test.Utils;

import com.sena.test.DTO.SecurityDTO.UserDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserDtoResponse;
import com.sena.test.Entity.Security.Person;
import com.sena.test.Entity.Security.User;

public class UserMapper {

    private UserMapper() {}

    public static User toEntity(UserDtoRequest dto, Person person) {
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword());
        user.setPerson(person);
        return user;
    }

    public static UserDtoResponse toResponseDto(User user) {
        if (user == null) return null;

        UserDtoResponse dto = new UserDtoResponse();
        dto.setId(user.getId());

        if (user.getPerson() != null) {
            dto.setPersonId(user.getPerson().getId());
            dto.setPersonName(user.getPerson().getName());
            dto.setPersonLastName(user.getPerson().getLastName());
        }

        return dto;
    }
}
