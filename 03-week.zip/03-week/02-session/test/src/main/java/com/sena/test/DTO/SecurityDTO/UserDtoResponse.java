package com.sena.test.DTO.SecurityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDtoResponse {

    private Long id;

    private Long personId;
    private String personName;
    private String personLastName;
}
