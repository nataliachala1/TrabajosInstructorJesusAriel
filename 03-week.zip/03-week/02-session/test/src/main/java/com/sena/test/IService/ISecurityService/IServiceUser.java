package com.sena.test.IService.ISecurityService;

import java.util.List;

import com.sena.test.DTO.SecurityDTO.UserDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserDtoResponse;

public interface IServiceUser {

    UserDtoResponse create(UserDtoRequest dto);
    UserDtoResponse update(Long id, UserDtoRequest dto);
    UserDtoResponse findById(Long id);
    List<UserDtoResponse> findAll();
    void delete(Long id);
}
