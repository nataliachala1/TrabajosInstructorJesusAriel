package com.sena.test.Controller.InventoryController;

import java.security.PublicKey;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.InventoryDTO.ProductDtoRequest;
import com.sena.test.DTO.InventoryDTO.ProductDtoResponse;
import com.sena.test.IService.IInventoryService.IServiceProduct;

@RestController
@RequestMapping("/API/products")
public class ProductController {

    private final IServiceProduct service;

    public ProductController(IServiceProduct service) {
        this.service = service;
    }

    @PostMapping
    public ProductDtoResponse create(@RequestBody ProductDtoRequest dto) {
        return service.create(dto);
    }
    @GetMapping
    public List<ProductDtoResponse> findAll() {
        return service.findAll();
    }
    @GetMapping("/{id}")
    public ProductDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }
    @PutMapping("/{id}")
    public ProductDtoResponse update(@PathVariable Long id, @RequestBody ProductDtoRequest dto) {
        return service.update(id, dto);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }


}
