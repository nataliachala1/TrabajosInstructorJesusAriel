package com.sena.test.IService.IBillService;

import java.util.List;

import com.sena.test.DTO.BillDTO.BillDtoRequest;
import com.sena.test.DTO.BillDTO.BillDtoResponse;

public interface IServiceBill {
    BillDtoResponse create (BillDtoRequest dto);

    List<BillDtoResponse> findAll();
    BillDtoResponse findById(Long id);
}
