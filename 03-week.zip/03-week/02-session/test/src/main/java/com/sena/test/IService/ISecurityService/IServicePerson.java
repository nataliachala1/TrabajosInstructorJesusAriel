package com.sena.test.IService.ISecurityService;

import java.util.List;

import com.sena.test.DTO.SecurityDTO.PersonDtoRequest;
import com.sena.test.DTO.SecurityDTO.PersonDtoResponse;

public interface IServicePerson {

    PersonDtoResponse create(PersonDtoRequest dto);

    PersonDtoResponse update(Long id, PersonDtoRequest dto);

    PersonDtoResponse findById(Long id);

    List<PersonDtoResponse> findAll();

    void delete(Long id);
}
