package com.sena.test.Utils;

import com.sena.test.DTO.BillDTO.BillDetailDtoRequest;
import com.sena.test.DTO.BillDTO.BillDetailDtoResponse;
import com.sena.test.Entity.Bill.Bill;
import com.sena.test.Entity.Bill.BillDetail;
import com.sena.test.Entity.Inventory.Product;

public class BillDetailMapper {

    private BillDetailMapper() {}

    public static BillDetail toEntity(BillDetailDtoRequest dto, Bill bill, Product product) {
        BillDetail detail = new BillDetail();
        detail.setQuantity(dto.getQuantity());
        detail.setPrice(dto.getPrice());
        detail.setBill(bill);
        detail.setProduct(product);
        return detail;
    }

    public static BillDetailDtoResponse toResponseDto(BillDetail detail) {
        BillDetailDtoResponse dto = new BillDetailDtoResponse();

        dto.setId(detail.getId());
        dto.setQuantity(detail.getQuantity());
        dto.setPrice(detail.getPrice());

        if (detail.getProduct() != null) {
            dto.setProductName(detail.getProduct().getName());
        }

        return dto;
    }
    
}
