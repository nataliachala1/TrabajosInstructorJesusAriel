package com.sena.test.IService.ISecurityService;

import java.util.List;


import com.sena.test.DTO.SecurityDTO.UserRolDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserRolDtoResponse;

public interface IServiceUserRol {

    UserRolDtoResponse create(UserRolDtoRequest dto);
    UserRolDtoResponse update(Long id, UserRolDtoRequest dto);
    UserRolDtoResponse findById(Long id);
    List<UserRolDtoResponse> findAll();
    void delete(Long id);
}
