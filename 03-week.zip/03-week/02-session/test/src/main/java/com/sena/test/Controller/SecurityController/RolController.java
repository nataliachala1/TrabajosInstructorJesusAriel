package com.sena.test.Controller.SecurityController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.sena.test.DTO.SecurityDTO.RolDtoRequest;
import com.sena.test.DTO.SecurityDTO.RolDtoResponse;
import com.sena.test.IService.ISecurityService.IServiceRol;

public class RolController {

    private final IServiceRol service;

    public RolController(IServiceRol service) {
        this.service = service;
    }

    @PostMapping
    public RolDtoResponse create(@RequestBody RolDtoRequest dto) {
        return service.create(dto);
    }
    @GetMapping
    public List<RolDtoResponse> findAll() {
        return service.findAll();
    }
    @GetMapping("/{id}")
    public RolDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }
    @PutMapping("/{id}")
    public RolDtoResponse update(@PathVariable Long id, @RequestBody RolDtoRequest dto) {
        return service.update(id, dto);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
