package com.sena.test.DTO.SecurityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRolDtoResponse{

    private Long id;
    private Long userId;
    private Long rolId;

}
