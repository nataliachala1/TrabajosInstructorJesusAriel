package com.sena.test.Controller.SecurityController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.SecurityDTO.UserDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserDtoResponse;
import com.sena.test.IService.ISecurityService.IServiceUser;

@RestController
@RequestMapping("/Api/users")
public class UserController {

    private final IServiceUser service;

    public UserController(IServiceUser service) {
        this.service = service;
    }

    @PostMapping
    public UserDtoResponse create(@RequestBody UserDtoRequest dto) {
        return service.create(dto);
    }

    @GetMapping
    public List<UserDtoResponse> findAll() {
        return service.findAll();
    } 
    @GetMapping("/{id}")
    public UserDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }
    @PutMapping("/{id}")
    public UserDtoResponse update(@PathVariable Long id, @RequestBody UserDtoRequest dto) {
        return service.update(id, dto);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }

}
