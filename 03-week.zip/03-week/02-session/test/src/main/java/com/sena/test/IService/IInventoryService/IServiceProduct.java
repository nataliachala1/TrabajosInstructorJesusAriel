package com.sena.test.IService.IInventoryService;

import java.util.List;

import com.sena.test.DTO.InventoryDTO.ProductDtoRequest;
import com.sena.test.DTO.InventoryDTO.ProductDtoResponse;

public interface IServiceProduct {

    ProductDtoResponse create (ProductDtoRequest dto);
    ProductDtoResponse update (long id, ProductDtoRequest dto);
    ProductDtoResponse findById (Long id);
    List<ProductDtoResponse> findAll();
    void delete (Long id);
}
