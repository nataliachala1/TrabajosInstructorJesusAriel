package com.sena.test.Service.BillService;

import java.util.List;
import java.util.stream.Collectors;

import com.sena.test.DTO.BillDTO.BillDtoRequest;
import com.sena.test.DTO.BillDTO.BillDtoResponse;
import com.sena.test.Entity.Bill.Bill;
import com.sena.test.Entity.Security.User;
import com.sena.test.IRepository.IBillRepository.IRepositoryBill;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryUser;
import com.sena.test.IService.IBillService.IServiceBill;
import com.sena.test.Utils.BillMapper;

public class ServiceBill implements IServiceBill{

    private final IRepositoryBill repositoryBill;
    private final IRepositoryUser repositoryUser;

    public ServiceBill(IRepositoryBill repositoryBill, IRepositoryUser repositoryUser) {
        this.repositoryBill = repositoryBill;
        this.repositoryUser = repositoryUser;
    }

    @Override
    public BillDtoResponse create(BillDtoRequest dto) {

        User user = repositoryUser.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found with id: " + dto.getUserId())); 
        Bill bill = BillMapper.toEntity(dto, user);
        bill = repositoryBill.save(bill);
        return BillMapper.toResponseDto(bill);
    }

    @Override
    public List<BillDtoResponse> findAll() {
        return repositoryBill.findAll()
                .stream()
                .map(BillMapper::toResponseDto)
                .collect(Collectors.toList());
    }
    @Override
    public BillDtoResponse findById(Long id) {
        Bill bill = repositoryBill.findById(id)
                .orElseThrow(() -> new RuntimeException("Bill not found with id: " + id));
        return BillMapper.toResponseDto(bill);
    }

}
