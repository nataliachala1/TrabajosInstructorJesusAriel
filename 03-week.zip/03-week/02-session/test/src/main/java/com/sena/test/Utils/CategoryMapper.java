package com.sena.test.Utils;

import com.sena.test.DTO.InventoryDTO.CategoryDtoRequest;
import com.sena.test.DTO.InventoryDTO.CategoryDtoResponse;
import com.sena.test.Entity.Inventory.Category;

public class CategoryMapper {

    private CategoryMapper() {}

    public static Category toEntity(CategoryDtoRequest dto) {
        Category category = new Category();
        category.setName(dto.getName());
        return category;
    }
    public static CategoryDtoResponse toResponse(Category category) {
        CategoryDtoResponse dto = new CategoryDtoResponse();
        dto.setId(category.getId());
        dto.setName(category.getName());
        return dto;
    }
}
