package com.sena.test.Service.InventoryService;

public class ServiceProduct {

}
