package com.sena.test.IRepository.IInventoryRepository;

import com.sena.test.Entity.Inventory.Category;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IRepositoryCategory extends JpaRepository<Category, Long>{

    Optional<Category> findByName(String name);

    boolean existsByName(String name);



}
