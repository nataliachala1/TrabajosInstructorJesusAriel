package com.sena.test.Controller.SecurityController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.SecurityDTO.PersonDtoRequest;
import com.sena.test.DTO.SecurityDTO.PersonDtoResponse;
import com.sena.test.IService.ISecurityService.IServicePerson;

@RestController
@RequestMapping("/API/Persons")
public class PersonController {

    private final IServicePerson service;

    public PersonController(IServicePerson service) {
        this.service = service;
    }

    @PostMapping
    public PersonDtoResponse create(@RequestBody PersonDtoRequest dto) {
        return service.create(dto);
    }
    @GetMapping
    public List<PersonDtoResponse> findAll() {
        return service.findAll();
    }
    @GetMapping("/{id")
    public PersonDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);

    }
    @PutMapping("/{id]")
    public PersonDtoResponse update(@PathVariable Long id, @RequestBody PersonDtoRequest dto) {
        return service.update(id, dto);

    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }


}
