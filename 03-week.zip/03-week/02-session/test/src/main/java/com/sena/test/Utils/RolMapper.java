package com.sena.test.Utils;

import com.sena.test.DTO.SecurityDTO.RolDtoRequest;
import com.sena.test.DTO.SecurityDTO.RolDtoResponse;
import com.sena.test.Entity.Security.Rol;

public class RolMapper {

    private RolMapper() {}

    public static Rol toEntity(RolDtoRequest dto) {
        Rol role = new Rol();
        role.setName(dto.getName());
        return role;
    }

    public static RolDtoResponse toResponseDto(Rol rol) {
        RolDtoResponse dto = new RolDtoResponse();
        dto.setId(rol.getId());
        dto.setName(rol.getName());
        return dto;
    }

}
