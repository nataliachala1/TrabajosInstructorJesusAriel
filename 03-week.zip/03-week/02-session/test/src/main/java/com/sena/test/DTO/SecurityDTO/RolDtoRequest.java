package com.sena.test.DTO.SecurityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RolDtoRequest {
    private String name;

}
