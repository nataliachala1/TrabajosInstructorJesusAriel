package com.sena.test.Service.SecurityService;

import java.util.List;
import java.util.stream.Collectors;

import com.sena.test.DTO.SecurityDTO.RolDtoRequest;
import com.sena.test.DTO.SecurityDTO.RolDtoResponse;
import com.sena.test.Entity.Security.Rol;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryRol;
import com.sena.test.IService.ISecurityService.IServiceRol;
import com.sena.test.Utils.RolMapper;

public class ServiceRol implements IServiceRol {

    private final IRepositoryRol repository;

    public ServiceRol(IRepositoryRol repository) {
        this.repository = repository;
    }

    @Override
    public RolDtoResponse create(RolDtoRequest dto) {
        Rol rol = RolMapper.toEntity(dto);
        return RolMapper.toResponseDto(repository.save(rol));
    }

    @Override
    public RolDtoResponse update(Long id, RolDtoRequest dto) {
        Rol rol = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Rol no encontrado"));
            rol.setName(dto.getName());
        return RolMapper.toResponseDto(rol);
    }

    @Override
    public RolDtoResponse findById(Long id) {
    Rol rol = repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Rol no encontrado"));
    return RolMapper.toResponseDto(rol);
}

    @Override
    public List<RolDtoResponse> findAll() {
        return repository.findAll()
            .stream()
            .map(RolMapper::toResponseDto)
            .collect(Collectors.toList());
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

}
