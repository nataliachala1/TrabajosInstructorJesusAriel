package com.sena.test.DTO.InventoryDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class CategoryDtoRequest {
    private String name;

}
