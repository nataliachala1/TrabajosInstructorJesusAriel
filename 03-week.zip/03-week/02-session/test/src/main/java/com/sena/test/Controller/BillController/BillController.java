package com.sena.test.Controller.BillController;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.BillDTO.BillDtoRequest;
import com.sena.test.DTO.BillDTO.BillDtoResponse;
import com.sena.test.IService.IBillService.IServiceBill;

@RestController
@RequestMapping("api/bills")
public class BillController {

    private final IServiceBill service;

    public BillController(IServiceBill service) {
        this.service = service;
    }

    @PostMapping
    public BillDtoResponse create(@RequestBody BillDtoRequest dto) {
        return service.create(dto);
    }
    @GetMapping
    public List<BillDtoResponse> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public BillDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }
    



}
