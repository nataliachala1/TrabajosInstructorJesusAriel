package com.sena.test.IService.IInventoryService;

import java.util.List;

import com.sena.test.DTO.InventoryDTO.CategoryDtoRequest;
import com.sena.test.DTO.InventoryDTO.CategoryDtoResponse;

public interface IServiceCategory {

    CategoryDtoResponse create (CategoryDtoRequest dto);
    CategoryDtoResponse update (Long id, CategoryDtoRequest dto);
    CategoryDtoResponse findById(Long id);
    List<CategoryDtoResponse> findAll();
    void delete (Long id);

}
