package com.sena.test.Utils;

import com.sena.test.DTO.SecurityDTO.PersonDtoRequest;
import com.sena.test.DTO.SecurityDTO.PersonDtoResponse;
import com.sena.test.Entity.Security.Person;

public class PersonMapper {

    private PersonMapper() {}

    public static Person toEntity(PersonDtoRequest dto) {
        Person person = new Person();
        person.setName(dto.getName());
        person.setLastName(dto.getLastName());
        person.setEmail(dto.getEmail());
        person.setIdentity(dto.getIdentity());
        return person;
    }
    public static PersonDtoResponse toResponseDto(Person person) {
        PersonDtoResponse dto = new PersonDtoResponse();
        dto.setId(person.getId());
        dto.setName(person.getName());
        dto.setLastName(person.getLastName());
        dto.setEmail(person.getEmail());
        return dto;
    }
    public static void updateEntity(Person person, PersonDtoRequest dto) {
        person.setName(dto.getName());
        person.setLastName(dto.getLastName());
        person.setEmail(dto.getEmail());
        person.setIdentity(dto.getIdentity());
    }
}
