package com.sena.test.Controller.SecurityController;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.test.DTO.SecurityDTO.UserRolDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserRolDtoResponse;
import com.sena.test.IService.ISecurityService.IServiceUserRol;

@RestController
@RequestMapping("/api/useroles")
public class UserRolController {

    private final IServiceUserRol service;

    public UserRolController(IServiceUserRol service) {
        this.service = service;
    }

    @PostMapping
    public UserRolDtoResponse create(@RequestBody UserRolDtoRequest dto) {
        return service.create(dto);
    }
    @GetMapping
    public List<UserRolDtoResponse> findAll() {
        return service.findAll();
    }
    @GetMapping("/{id}")
    public UserRolDtoResponse findById(@PathVariable Long id) {
        return service.findById(id);
    }
    @PutMapping("/{id}")
    public UserRolDtoResponse update(@PathVariable Long id, @RequestBody UserRolDtoRequest dto) {
        return service.update(id, dto);
    }
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
