
package com.sena.test.Service.SecurityService;

import org.springframework.stereotype.Service;
import com.sena.test.DTO.SecurityDTO.UserRolDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserRolDtoResponse;
import com.sena.test.Entity.Security.Rol;
import com.sena.test.Entity.Security.User;
import com.sena.test.Entity.Security.UserRol;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryRol;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryUser;
import com.sena.test.IRepository.ISecurityRepository.IRepositoryUserRol;
import com.sena.test.IService.ISecurityService.IServiceUserRol;
import com.sena.test.Utils.UserRolMapper;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ServiceUserRol implements IServiceUserRol {

    private final IRepositoryUserRol repository;
    private final IRepositoryUser userRepository;
    private final IRepositoryRol rolRepository;

    public ServiceUserRol(IRepositoryUserRol repository,
                           IRepositoryUser userRepository,
                           IRepositoryRol rolRepository) {
        this.repository = repository;
        this.userRepository = userRepository;
        this.rolRepository = rolRepository;
    }

    @Override
    public UserRolDtoResponse create(UserRolDtoRequest dto) {

        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Rol rol = rolRepository.findById(dto.getRolId())
                .orElseThrow(() -> new RuntimeException("Rol no encontrado"));

        UserRol userRol = new UserRol();
        userRol.setUser(user);
        userRol.setRol(rol);

        return UserRolMapper.toResponseDto(repository.save(userRol));
    }

    @Override
    public UserRolDtoResponse update(Long id, UserRolDtoRequest dto) {

        UserRol userRol = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("UserRole no encontrado"));

        User user = userRepository.findById(dto.getUserId())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Rol rol = rolRepository.findById(dto.getRolId())
                .orElseThrow(() -> new RuntimeException("Rol no encontrado"));

        userRol.setUser(user);
        userRol.setRol(rol);

        return UserRolMapper.toResponseDto(repository.save(userRol));
    }

    @Override
    public UserRolDtoResponse findById(Long id) {

        UserRol userRol = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("UserRol no encontrado"));

        return UserRolMapper.toResponseDto(userRol);
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("UserRol no encontrado");
        }
        repository.deleteById(id);
    }

    @Override
    public List<UserRolDtoResponse> findAll() {
        return repository.findAll()
                .stream()
                .map(UserRolMapper::toResponseDto)
                .collect(Collectors.toList());
    }
}
