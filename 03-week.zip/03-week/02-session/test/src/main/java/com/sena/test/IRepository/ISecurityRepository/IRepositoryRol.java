package com.sena.test.IRepository.ISecurityRepository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.sena.test.Entity.Security.Rol;

public interface IRepositoryRol extends JpaRepository<Rol, Long> {

    Optional<Rol> findByName(String name);

}
