package com.sena.test.DTO.InventoryDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDtoResponse {
    private Long id;
    private String name;

}
