package com.sena.test.IRepository.ISecurityRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.test.Entity.Security.Person;

public interface IRepositoryPerson extends JpaRepository<Person, Long> {

    Optional<Person> findByEmail(String email);
    
    Optional<Person> findByIdentity(String identity);
}
