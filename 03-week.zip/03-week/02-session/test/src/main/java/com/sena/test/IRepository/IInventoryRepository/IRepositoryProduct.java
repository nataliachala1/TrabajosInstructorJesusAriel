package com.sena.test.IRepository.IInventoryRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.test.Entity.Inventory.Product;
import java.util.List;


public interface IRepositoryProduct extends JpaRepository<Product, Long>{

    Optional<Product> findByName(String name);

    boolean existsByName(String name);

    List<Product> findByCategoryId(Long categoryId);

}
