package com.sena.test.Utils;

import java.util.stream.Collectors;

import com.sena.test.DTO.BillDTO.BillDtoRequest;
import com.sena.test.DTO.BillDTO.BillDtoResponse;
import com.sena.test.Entity.Bill.Bill;
import com.sena.test.Entity.Security.User;

public class BillMapper {

    private BillMapper() {}
    
    public static Bill toEntity(BillDtoRequest dto, User user) {
        Bill bill = new Bill();
        bill.setDate(dto.getDate());
        bill.setUser(user);
        bill.setTotal(0.00);
        return bill;
    }
    public static BillDtoResponse toResponseDto(Bill bill) {
        BillDtoResponse dto = new BillDtoResponse();

        dto.setId(bill.getId());
        dto.setDate(bill.getDate());
        dto.setTotal(bill.getTotal());

        if (bill.getUser() != null && bill.getUser().getPerson() != null) {
            dto.setUsername(bill.getUser().getPerson().getName());
        }

        if (bill.getBillDetails() != null) {
            dto.setDetails(
                bill.getBillDetails()
                        .stream()
                        .map(BillDetailMapper::toResponseDto)
                        .collect(Collectors.toList())
            );
        }

        return dto;

    }
}
