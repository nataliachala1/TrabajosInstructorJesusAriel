package com.sena.test.Utils;

import com.sena.test.DTO.SecurityDTO.UserRolDtoRequest;
import com.sena.test.DTO.SecurityDTO.UserRolDtoResponse;
import com.sena.test.Entity.Security.Rol;
import com.sena.test.Entity.Security.User;
import com.sena.test.Entity.Security.UserRol;

public class UserRolMapper {

    private UserRolMapper() {}

    public static UserRol toEntity(UserRolDtoRequest dto, User user, Rol rol) {
        UserRol userRol = new UserRol();
        userRol.setUser(user);
        userRol.setRol(rol);
        return userRol;
    }

    public static UserRolDtoResponse toResponseDto(UserRol userRol) {
        UserRolDtoResponse dto = new UserRolDtoResponse();
        dto.setId(userRol.getId());

        if (userRol.getUser() != null) {
            dto.setUserId(userRol.getUser().getId());
        }

        if (userRol.getRol() != null) {
            dto.setRolId(userRol.getRol().getId());
        }

        return dto;
    }

}
